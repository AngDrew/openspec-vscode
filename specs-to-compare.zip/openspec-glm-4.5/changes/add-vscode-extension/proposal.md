## Why
To create a VS Code extension that seamlessly integrates the OpenSpec command-line tool, providing a user-friendly interface to manage specifications and changes directly within the editor, offering a "Copilot-like" experience for spec-driven development.

## What Changes
- Create VS Code extension with activity bar integration
- Implement OpenSpec Explorer view for specs and changes 
- Add command palette integration for OpenSpec operations
- Build detailed view webview for rich change visualization
- Implement file system watcher for automatic refresh
- Provide workspace initialization detection and guidance

## Impact
- Affected specs: New capability - vscode-extension
- Affected code: New VS Code extension package.json, extension.ts, webview providers
- New files: Extension entry point, activity bar view, command handlers, webview HTML/JS/CSS