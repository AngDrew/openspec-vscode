## Why
To create a VS Code extension that seamlessly integrates the OpenSpec command-line tool, providing a user-friendly interface to manage specifications and changes directly within the editor. The extension will offer a "Copilot-like" experience for spec-driven development, visualizing proposals, changes, and their statuses in a dedicated sidebar.

## What Changes
- Create VS Code extension with activity bar integration for OpenSpec
- Implement OpenSpec Explorer view displaying Changes and Specifications sections
- Add command palette integration for OpenSpec operations
- Build detailed view webview for rich change visualization
- Implement file system watcher for automatic refresh of the OpenSpec Explorer
- Provide workspace initialization detection and welcome view for uninitialized workspaces

## Impact
- Affected specs: New capability - vscode-extension
- Affected code: New VS Code extension package.json, extension.ts, activity bar provider, webview provider
- New files: Extension entry point, tree data provider, command handlers, webview HTML/JS/CSS, file system watcher