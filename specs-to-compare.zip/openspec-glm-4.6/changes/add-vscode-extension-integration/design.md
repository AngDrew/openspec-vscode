## Context
This change introduces a VS Code extension to integrate OpenSpec functionality directly into the editor. The extension needs to interact with the file system, parse OpenSpec files, provide rich UI components, and maintain state synchronization between the file system and VS Code's UI. This is a cross-cutting change involving multiple VS Code APIs (Activity Bar, Tree View, Webview, Commands, File System Watcher).

## Goals / Non-Goals
- Goals: 
  - Provide seamless OpenSpec integration within VS Code
  - Enable visual browsing of specs and changes
  - Offer rich formatting for change details
  - Maintain real-time synchronization with file system
  - Follow VS Code design principles and accessibility standards
- Non-Goals:
  - Editing OpenSpec files directly in the UI (initial version)
  - Full CLI command integration beyond basic viewing
  - Language server integration for proposals
  - CodeLens or inline code actions

## Decisions

### Extension Architecture
- **Decision**: Use TypeScript with VS Code Extension API
- **Alternatives considered**: JavaScript (less type safety), external language server (overkill for V1)
- **Rationale**: TypeScript provides better maintainability and IDE support, VS Code Extension API is mature and well-documented

### UI Framework
- **Decision**: Native VS Code Tree View + Webview for details
- **Alternatives considered**: Custom WebView for entire UI, External UI framework
- **Rationale**: Tree View integrates better with VS Code's activity bar and provides native performance. Webview only for rich detail display where needed.

### File System Integration
- **Decision**: VS Code FileSystemWatcher API with debounced refresh
- **Alternatives considered**: Polling, Node.js fs.watch (cross-platform issues)
- **Rationale**: VS Code's API handles platform differences and provides proper integration with VS Code's event system

### State Management
- **Decision**: Tree data provider with in-memory caching
- **Alternatives considered**: Persistent state, file-based cache
- **Rationale**: OpenSpec files are text-based and fast to parse. Simpler to re-parse on changes than manage cache invalidation.

## Risks / Trade-offs
- **Performance**: Large OpenSpec repositories with many files could cause UI lag
  - **Mitigation**: Implement lazy loading, limit visible items, add pagination if needed
- **File System Complexity**: Complex folder structures might be hard to navigate
  - **Mitigation**: Clean tree organization, clear visual hierarchy, search functionality
- **VS Code API Compatibility**: API changes could break extension
  - **Mitigation**: Pin to stable API versions, regular testing with VS Code updates
- **Memory Usage**: Webview instances and file parsing could consume memory
  - **Mitigation**: Dispose unused webviews, implement efficient parsing, cache limiting

## Migration Plan
1. **Setup Phase**: Create basic extension structure and manifest
2. **Core UI**: Implement Activity Bar view with basic tree structure
3. **Integration Phase**: Add file system watching and command handling
4. **Rich UI**: Implement webview for detailed views
5. **Polish Phase**: Add error handling, testing, and documentation
6. **Release Phase**: Package for marketplace and gather user feedback

Rollback strategy: Extension can be disabled without affecting OpenSpec CLI functionality. Files are read-only initially, so no risk of data corruption.

## Open Questions
- Should the extension require OpenSpec CLI to be installed separately, or bundle minimal functionality?
- How should the extension handle malformed or incomplete OpenSpec files?
- What is the maximum file size/complexity the extension should handle before showing warnings?
- Should the extension provide any offline functionality when OpenSpec CLI is unavailable?