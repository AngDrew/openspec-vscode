## Context

Provide a lightweight VS Code extension that integrates with existing OpenSpec project layout. The goal is to be opinionated but minimal: surface specs and changes, allow quick navigation and viewing, and prepare for future integrations.

## Goals / Non-Goals

- Goals:
  - Minimal startup impact
  - Accurate reflection of `openspec/` state
  - Good UX aligned with VS Code patterns
- Non-Goals:
  - Full two-way editing of specs (v1 reads and opens files)
  - Deep language-server integrations (future work)

## Decisions

- TreeDataProvider: Use a single TreeDataProvider with two top-level nodes: `Changes` and `Specifications`.
- Webview: Use a Webview for rich rendering of `proposal.md` and `tasks.md` with sanitized HTML.
- FileSystemWatcher: Use `workspace.createFileSystemWatcher('**/openspec/**')` scoped to workspace root; debounce refresh events.
- Launch: Activation on `onView:openspecExplorer` and `workspaceContains:openspec` to avoid impacting startup.

## Alternatives Considered

- Inline editor previews vs Webview: Webview chosen for formatted content rendering and easier future extension (CSS, JS).
- Multiple providers vs single provider: Single provider reduces complexity and keeps consistent refresh handling.

## Risks / Trade-offs

- Using a Webview requires careful sanitization to avoid XSS from markdown. Mitigation: render markdown on extension side using a safe renderer and strip scripts.
- FileSystemWatcher may produce many events in large repos. Mitigation: debounce and batch updates.

## Migration Plan

1. Deliver read-only explorer and webview.
2. Add proposal scaffold command to create initial files in `openspec/changes/<id>/`.
3. Iterate on two-way editing and CodeLens features as follow-ups.

## Open Questions

- Should the extension auto-run `openspec init` or only offer guidance? (Recommendation: guidance only for safety)
- Which iconography should be used for the Activity Bar entry? (Use default file/gear icons initially)
