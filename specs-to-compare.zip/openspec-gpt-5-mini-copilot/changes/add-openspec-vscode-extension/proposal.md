## Why

Developers using OpenSpec will benefit from an integrated VS Code experience that surfaces changes and specifications without leaving the editor. A lightweight extension will lower friction for spec-driven development and make it easier to author, review, and navigate proposals.

## What Changes

- Add a new change `add-openspec-vscode-extension` to introduce the VS Code extension capability.
- Add spec deltas for a `vscode` capability under `openspec/changes/add-openspec-vscode-extension/specs/vscode/spec.md`.
- Provide `tasks.md` with a small, verifiable implementation plan.
- Provide `design.md` documenting architecture choices, trade-offs, and extensibility points.

## Impact

- Affected specs: `vscode`
- Affected code: tooling and optional VS Code extension scaffolding (outside repo)
- Non-breaking: This is additive and does not change existing specs.
