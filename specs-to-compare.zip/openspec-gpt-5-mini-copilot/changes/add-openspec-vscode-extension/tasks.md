## 1. Implementation

- [ ] 1.1 Scaffold VS Code extension project skeleton (README, package.json, activation events)
- [ ] 1.2 Implement `OpenSpec` explorer TreeDataProvider to read `openspec/changes` and `openspec/specs` directories
- [ ] 1.3 Add Webview panel to render change details (`proposal.md`, `tasks.md`, summary)
- [ ] 1.4 Register Command Palette commands: `OpenSpec: View Details`, `OpenSpec: List Changes`, `OpenSpec: Generate Proposal`
- [ ] 1.5 Implement FileSystemWatcher on `openspec/` and hook to explorer refresh
- [ ] 1.6 Add icons and status badges for active/completed changes
- [ ] 1.7 Write unit and integration tests for the provider and commands
- [ ] 1.8 Document extension usage in `openspec/changes/add-openspec-vscode-extension/README.md`

## 2. Validation

- [ ] 2.1 Run `openspec validate add-openspec-vscode-extension --strict` and fix any issues
- [ ] 2.2 Verify explorer updates on file changes
- [ ] 2.3 Verify commands appear and execute correctly
