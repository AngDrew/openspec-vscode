## ADDED Requirements

### Requirement: VS Code Integration for OpenSpec
The system SHALL provide an official VS Code extension that integrates with the OpenSpec workspace layout and CLI to surface changes and specifications within the editor.

#### Scenario: Workspace Not Initialized
- **WHEN** a user opens a workspace without an `openspec` directory
- **THEN** the extension SHALL show a welcome view prompting the user to run `openspec init` and offer a command to open the terminal or execute the init command.

#### Scenario: Workspace Initialized
- **WHEN** a user opens a workspace containing `openspec/`
- **THEN** the extension SHALL show an `OpenSpec` explorer in the Activity Bar with `Changes` and `Specifications` sections.

#### Scenario: OpenSpec Explorer Interaction
- **WHEN** a user clicks a change in the `Changes` section
- **THEN** the extension SHALL open a detailed Webview showing `proposal.md`, `tasks.md`, `proposal summary`, and `tasks` for that change.

#### Scenario: Spec Item Open
- **WHEN** a user clicks a specification in the `Specifications` section
- **THEN** the extension SHALL open the `spec.md` file in the editor.

#### Scenario: File System Changes
- **WHEN** files under `openspec/` are added, removed, or modified
- **THEN** the extension SHALL refresh the explorer view to reflect the latest state.

## ADDED Requirements

### Requirement: Command Palette Integration
The system SHALL register commands in the VS Code Command Palette:
- `OpenSpec: View Details` — opens the detailed view for the selected change.
- `OpenSpec: List Changes` — focuses and refreshes the OpenSpec explorer.
- `OpenSpec: Generate Proposal` — scaffolds a new proposal directory and files (initial version will only create files locally; integration with `/openspec:proposal` workflow is for future work).

#### Scenario: Command Execution
- **WHEN** a user invokes `OpenSpec: List Changes`
- **THEN** the extension SHALL refresh the explorer and reveal the view.

## ADDED Requirements

### Requirement: Performance and Reliability
The extension SHALL implement file system watching efficiently and handle malformed `openspec` directories gracefully, showing user-friendly errors.

#### Scenario: Malformed Openspec
- **WHEN** the `openspec` directory is present but missing expected files
- **THEN** the extension SHALL show a non-blocking warning in the explorer and provide a link to run `openspec update` or open `openspec/project.md`.
