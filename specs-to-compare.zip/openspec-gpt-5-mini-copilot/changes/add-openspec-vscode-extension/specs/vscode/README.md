Specification delta for the OpenSpec VS Code extension capability.
